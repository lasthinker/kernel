/* SPDX-License-Identifier: GPL-2.0 */

#ifndef _DT_BINDINGS_IIO_ADC_INGENIC_ADC_H
#define _DT_BINDINGS_IIO_ADC_INGENIC_ADC_H

/* ADC channel idx. */
#define INGENIC_ADC_AUX		0
#define INGENIC_ADC_BATTERY	1

#endif
